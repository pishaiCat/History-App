
import React from 'react';
import type { GeneratedImage } from '../types';
import { DownloadIcon, RefreshIcon } from './icons';

interface ImageCardProps {
  image: GeneratedImage;
  onRegenerate: (id: string, prompt: string) => void;
  onImageClick: (imageUrl: string) => void;
  index: number;
}

export const ImageCard: React.FC<ImageCardProps> = ({ image, onRegenerate, onImageClick, index }) => {

  const handleDownload = () => {
    if (!image.imageUrl) return;
    const link = document.createElement('a');
    link.href = image.imageUrl;
    link.download = `${index + 1}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  
  return (
    <div className="bg-gray-800 rounded-lg overflow-hidden shadow-lg transform hover:scale-105 transition-transform duration-300">
      <div className="aspect-square w-full bg-gray-700 flex items-center justify-center relative group">
        {image.status === 'generating' && (
          <div className="animate-pulse flex flex-col items-center justify-center text-gray-400">
            <svg className="animate-spin h-10 w-10 text-indigo-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
            <span className="mt-3 text-sm">Generating...</span>
          </div>
        )}
        {image.status === 'done' && image.imageUrl && (
          <>
            <img src={image.imageUrl} alt={image.prompt} className="w-full h-full object-contain" />
            <button
              onClick={() => onImageClick(image.imageUrl!)}
              className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity focus:opacity-100 focus:outline-none"
              aria-label={`View larger image for prompt: ${image.prompt}`}
            >
              <span className="text-white text-lg font-semibold">View Image</span>
            </button>
          </>
        )}
        {image.status === 'error' && (
          <div className="p-4 text-center text-red-400">
            <p className="font-semibold">Generation Failed</p>
            <p className="text-xs mt-2">{image.error}</p>
          </div>
        )}
      </div>
      <div className="p-4">
        <p className="text-sm text-gray-300 truncate" title={image.prompt}>{image.prompt}</p>
        <div className="mt-3 flex items-center justify-end space-x-2">
          <button 
            onClick={() => onRegenerate(image.id, image.prompt)}
            className="p-2 rounded-full text-gray-400 hover:bg-gray-700 hover:text-white transition-colors"
            title="Regenerate"
          >
            <RefreshIcon className="w-5 h-5" />
          </button>
          <button 
            onClick={handleDownload}
            disabled={!image.imageUrl}
            className="p-2 rounded-full text-gray-400 hover:bg-gray-700 hover:text-white disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            title="Download"
          >
            <DownloadIcon className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
};
