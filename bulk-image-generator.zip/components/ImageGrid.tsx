
import React from 'react';
import type { GeneratedImage } from '../types';
import { ImageCard } from './ImageCard';
import { SparklesIcon } from './icons';

interface ImageGridProps {
  images: GeneratedImage[];
  onRegenerate: (id: string, prompt: string) => void;
  onImageClick: (imageUrl: string) => void;
}

export const ImageGrid: React.FC<ImageGridProps> = ({ images, onRegenerate, onImageClick }) => {
  if (images.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center text-gray-500 p-8 border-2 border-dashed border-gray-700 rounded-lg">
        <SparklesIcon className="w-16 h-16 mb-4 text-gray-600"/>
        <h3 className="text-xl font-semibold text-gray-400">Your Canvas Awaits</h3>
        <p className="mt-2 max-w-md">Add your prompts, choose a style, and click 'Generate' to see the magic happen here!</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 xl:grid-cols-3 gap-6">
      {images.map((image, index) => (
        <ImageCard 
          key={image.id} 
          image={image} 
          onRegenerate={onRegenerate} 
          onImageClick={onImageClick}
          index={index} 
        />
      ))}
    </div>
  );
};
