
import React from 'react';

interface PromptInputProps {
  prompts: string;
  onPromptsChange: (value: string) => void;
  isDisabled: boolean;
}

export const PromptInput: React.FC<PromptInputProps> = ({ prompts, onPromptsChange, isDisabled }) => {
  return (
    <div className="w-full">
      <label htmlFor="prompts" className="block mb-2 text-sm font-medium text-gray-300">
        Enter prompts (one per line)
      </label>
      <textarea
        id="prompts"
        rows={10}
        value={prompts}
        onChange={(e) => onPromptsChange(e.target.value)}
        disabled={isDisabled}
        className="block p-2.5 w-full text-sm rounded-lg border focus:ring-indigo-500 focus:border-indigo-500 bg-gray-800 border-gray-600 placeholder-gray-400 text-white transition-colors"
        placeholder={
`The character is surfing a giant wave
The character is cooking ramen in a futuristic city
The character is exploring a glowing alien jungle
The character is a detective in a 1940s noir film`
        }
      ></textarea>
    </div>
  );
};
